// Store cart items in local storage with key: "items"
